package com.example.petstore;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText idPet;
    private Button mainBtn, add;
    private TextView textPet;
    private ImageView imgPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idPet = findViewById(R.id.idPet);
        mainBtn = findViewById(R.id.mainBtn);
        add = findViewById(R.id.btnAdd);
        textPet = findViewById(R.id.textPet);
        imgPhoto = findViewById(R.id.imagePet);


        mainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(idPet.getText().toString().trim().equals(""))
                    Toast.makeText(MainActivity.this, R.string.text_input, Toast.LENGTH_LONG).show();
                else {
                    String id = idPet.getText().toString();
                    String url = "https://petstore.swagger.io/v2/pet/" + id;

                    //String urlPhoto = "https://petstore.swagger.io/v2/pet/" + id +"/uploadImage";
                    //Picasso.with(MainActivity.this).load(urlPhoto).into(imgPhoto);
                    new GetURLData().execute(url);
                }
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddActivity.class));
            }
        });
    }

    private class GetURLData extends AsyncTask<String, String, String>{

        protected void onPreExecute(){
            textPet.setText("Ожидайте...");
        }

        @Override
        protected String doInBackground(String... strings) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                InputStream stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null)
                    buffer.append(line).append("\n");

                return buffer.toString();
            }catch (MalformedURLException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }finally {
                if (connection != null)
                    connection.disconnect();

                try {
                    if (reader != null)
                        reader.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
            return null;
        }
        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);

            try {
                JSONObject jsonObject = new JSONObject(result);
                textPet.setText("ID: " + jsonObject.getInt("id") +
                        "\nCategory: " + jsonObject.getJSONObject("category").getString("name") +
                        "\nName: " +  jsonObject.getString("name") +
                        "\nStatus: " + jsonObject.getString("status"));

                String urlPet = jsonObject.getJSONArray("photoUrls").getString(0);
                Glide.with(MainActivity.this).load(urlPet).into(imgPhoto);

            }catch (JSONException e){
                e.printStackTrace();
            }
        }
    }
}