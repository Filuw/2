package com.example.petstore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AddActivity extends AppCompatActivity {
    ArrayList<Category> petList = new ArrayList<>();
    private EditText id, name, category, status, imgPet;
    private Button addNewPet;
    ImageButton back;
    private PetstoreAPI petstoreAPI;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        id = findViewById(R.id.idPet);
        name = findViewById(R.id.namePet);
        category = findViewById(R.id.categoryPet);
        status = findViewById(R.id.statusPet);
        back = findViewById(R.id.backBtn);
        addNewPet = findViewById(R.id.newPet);
        imgPet = findViewById(R.id.newImgPet);

        //https://www.youtube.com/watch?v=Y3lra9efr08

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://petstore.swagger.io/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        petstoreAPI = retrofit.create(PetstoreAPI.class);

        addNewPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String petName = name.getText().toString();
                String petStatus = status.getText().toString();
                String petId = id.getText().toString();
                String petCategory = category.getText().toString();
                String petImg = imgPet.getText().toString();

                addPet(petName, petStatus, petId, petCategory, petImg);

                /*Category categoryPet = new Category();
                categoryPet.setName(String.valueOf(category));
                petList.add(categoryPet);
                JSONObject jsonObject = createCategoryPet();
                apiCall(jsonObject);*/
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddActivity.this, MainActivity.class));
            }
        });
    }

    /*private void apiCall(JSONObject jsonObject) {
    }

    public JSONObject createCategoryPet(){
        JSONObject object = null;
        try {
            JSONObject object1 = new JSONObject();
            JSONObject object2 = new JSONObject();

            JSONArray jsonArray = new JSONArray();

            for (int i = 0; i < petList.size(); i++){
                object2.put("name", petList.get(i).getName());
                jsonArray.put(object2);
            }
        }
    }*/


    private void addPet(String petName, String petStatus, String petId, String petCategory, String petImg) {
        Pet pet = new Pet();
        pet.setName(petName);
        pet.setStatus(petStatus);
        pet.setId(Long.parseLong(petId));
        pet.setCategory(pet.getCategory(petCategory));
        pet.setPhotoUrls(pet.getPhotoUrls(petImg));


        petstoreAPI.addPet(pet).enqueue(new Callback<Pet>() {
            @Override
            public void onResponse(@NonNull Call<Pet> call, @NonNull Response<Pet> response) {
                if (response.isSuccessful()) {
                    Pet pet = response.body();
                    if (pet != null) {
                        String petId = String.valueOf(pet.getId());
                        Toast.makeText(AddActivity.this, "New pet added! ", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(AddActivity.this, "Error: pet not added( ", Toast.LENGTH_SHORT).show();

                    }

                } else {
                    Toast.makeText(AddActivity.this, "Response not successful ", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(@NonNull Call<Pet> call, @NonNull Throwable t) {
                Toast.makeText(AddActivity.this, "Network error ", Toast.LENGTH_SHORT).show();

            }
        });
    }
}